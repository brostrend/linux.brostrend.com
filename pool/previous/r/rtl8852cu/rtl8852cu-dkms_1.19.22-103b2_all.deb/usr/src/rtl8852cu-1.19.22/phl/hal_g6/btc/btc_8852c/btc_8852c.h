/******************************************************************************
 *
 * Copyright(c) 2016 - 2019 Realtek Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 *****************************************************************************/
#ifndef __RTL8852C_BTC_H__
#define __RTL8852C_BTC_H__
/* rtl8852c_btc.c */

#define R_BTC_RF_BTG_CTRL 0x2
#define R_BTC_RF_LUT_EN 0xEF
#define R_BTC_RF_LUT_WA 0x33
#define R_BTC_RF_LUT_WD0 0x3f
#define R_BTC_RF_LUT_WD1 0x3e
#define R_BTC_RF_LUT_WD2 0x3d

#define R_BTC_BB_ANT_DIV_CTRL 0x1586c
#define R_BTC_BB_BTG_RX 0x980
#define R_BTC_BB_PRE_AGC_S1 0x476C
#define R_BTC_BB_PRE_AGC_S0 0x4688

#define R_BTC_CFG 0xDA00
#define R_BTC_BT_CNT_CFG 0xDA10
#define R_BTC_COEX_WL_REQ 0xDA24
#define R_BTC_BREAK_TABLE 0xDA44
#define R_BTC_BT_CNT_HIGH 0xDA14
#define R_BTC_BT_CNT_LOW 0xDA18

#define R_BTC_CFG_V2 0xDB00//R_AX_BTC_CFG_V2
#define R_BTC_RTK_MODE_CFG2 0xDB04
#define R_BTC_BT_CNT_CFG2 0xDB10
#define R_BTC_COEX_WL_REQ2 0xDB24
#define R_BTC_COEX_SEL2 0xDB30
#define R_BTC_COEX_TABLE_2_2 0xDB3C
#define R_BTC_BREAK_TABLE_2 0xDB44

#define B_BTC_TX_BCN_HI BIT(22)
#define B_BTC_TX_TRI_HI BIT(17)
#define B_BTC_RSP_ACK_HI BIT(10)
#define B_BTC_PRI_MASK_TX_TIME (BIT(4) | BIT(3))
#define B_BTC_PRI_MASK_RX_TIME_V1 (BIT(2) | BIT(1))
#define B_BTC_BT_CNT_RST_V1 BIT(1)
#define B_BTC_BT_CNT_EN BIT(0)
#define B_BTC_BB_GNT_MUX 0x001e0000
#define B_BTC_BB_PRE_AGC_MASK bMASKB3
#define B_BTC_BB_PRE_AGC_VAL 0x80000000

#define B_BTC_EN BIT(31)
#define B_BTC_EXT_BT_PINMUX BIT(29)
#define B_BTC_PTA_4WIRE_MODE (BIT(25) | BIT(24))
#define B_BTC_PTA_4WIRE_MODE_SH 24
#define B_BTC_IGN_EXT_GWL BIT(18)
#define B_BTC_IGN_EXT_GBT (BIT(7) | BIT(6) | BIT(5))

extern const struct btc_chip chip_8852c;
void _8852c_rfe_type(struct btc_t *btc);
void _8852c_init_cfg(struct btc_t *btc);
void _8852c_wl_tx_power(struct btc_t *btc, u32 level);
void _8852c_wl_rx_gain(struct btc_t *btc, u32 level);
void _8852c_wl_btg_standby(struct btc_t *btc, u32 state);
void _8852c_wl_req_mac(struct btc_t *btc, u8 mac_id);
void _8852c_get_reg_status(struct btc_t *btc, u8 type, void *status);
u8 _8852c_bt_rssi(struct btc_t *btc, u8 val);
#endif /*__RTL8852C_PHY_H__*/
