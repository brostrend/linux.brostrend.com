#ifndef _MAC_AUTOGEN_FUNC_TOP_G6_H_
#define _MAC_AUTOGEN_FUNC_TOP_G6_H_
#if MAC_AX_8852A_SUPPORT
#include "8852a/err_flag_auto_gen_8852a.h"
#include "8852a/dbgpkg_auto_gen_8852a.h"
#include "8852a/ser_auto_gen_8852a.h"
#endif
#if MAC_AX_8852B_SUPPORT
#include "8852b/err_flag_auto_gen_8852b.h"
#include "8852b/dbgpkg_auto_gen_8852b.h"
#include "8852b/ser_auto_gen_8852b.h"
#endif
#if MAC_AX_8852C_SUPPORT
#include "8852c/err_flag_auto_gen_8852c.h"
#include "8852c/dbgpkg_auto_gen_8852c.h"
#include "8852c/ser_auto_gen_8852c.h"
#endif
#if MAC_AX_8852D_SUPPORT
#include "8852d/err_flag_auto_gen_8852d.h"
#include "8852d/dbgpkg_auto_gen_8852d.h"
#include "8852d/ser_auto_gen_8852d.h"
#endif
#if MAC_AX_8192XB_SUPPORT
#include "8192xb/err_flag_auto_gen_8192xb.h"
#include "8192xb/dbgpkg_auto_gen_8192xb.h"
#include "8192xb/ser_auto_gen_8192xb.h"
#endif
#if MAC_AX_8852BT_SUPPORT
#include "8852bt/err_flag_auto_gen_8852bt.h"
#include "8852bt/dbgpkg_auto_gen_8852bt.h"
#include "8852bt/ser_auto_gen_8852bt.h"
#endif
#if MAC_AX_8851B_SUPPORT
#include "8851b/err_flag_auto_gen_8851b.h"
#include "8851b/dbgpkg_auto_gen_8851b.h"
#include "8851b/ser_auto_gen_8851b.h"
#endif
#endif
