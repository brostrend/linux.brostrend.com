void *aicwf_prealloc_txq_alloc(size_t size);

void aicwf_prealloc_txq_free(void);

